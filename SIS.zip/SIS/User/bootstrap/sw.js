self.importScripts('/assets/js/vendor/{fileName}')

const workboxSW = new self.WorkboxSW()
workboxSW.precache([])
