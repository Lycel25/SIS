<?php
include('db.php');
include('SApp_function.php');
if(isset($_POST["user_id"]))
{
	$output = array();
	$statement = $connection->prepare(
		"SELECT * FROM tbl_appform 
		WHERE id = '".$_POST["user_id"]."' 
		LIMIT 1"
	);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output["date"] = $row["date"];
		$output["studnum"] = $row["studnum"];
		$output["fullname"] = $row["fullname"];
		$output["gender"] = $row["gender"];
		$output["scholarship_name"] = $row["scholarship_name"];
		$output["gpa"] = $row["gpa"];
		$output["course"] = $row["course"];
		$output["yearlvl"] = $row["yearlvl"];
		$output["semester"] = $row["semester"];
		
	}
	echo json_encode($output);
}
?>