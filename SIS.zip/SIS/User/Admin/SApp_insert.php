<?php
include('db.php');
include('SApp_function.php');
if(isset($_POST["operation"]))
{
	
	if($_POST["operation"] == "Edit")
	{
		
		$statement = $connection->prepare(
			"UPDATE tbl_appform 
			SET date = :date, studnum = :studnum, fullname = :fullname, gender = :gender, scholarship_name = :scholarship_name, gpa = :gpa, course = :course, yearlvl = :yearlvl, semester = :semester
			WHERE id = :id
			"
		);
		$result = $statement->execute(
			array(
				':date'	=>	$_POST["date"],
				':studnum'	=>	$_POST["studnum"],
				':fullname'			=>	$_POST["fullname"],
				':gender'	=>	$_POST["gender"],
				':scholarship_name'	=>	$_POST["scholarship_name"],
				':gpa'			=>	$_POST["gpa"],
				':course'	=>	$_POST["course"],
				':yearlvl'	=>	$_POST["yearlvl"],
				':semester'			=>	$_POST["semester"],
				':id'			=>	$_POST["user_id"]
			)
		);
		if(!empty($result))
		{
			echo 'Data Updated';
		}
	}
}

?>