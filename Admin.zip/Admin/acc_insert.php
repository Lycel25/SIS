<?php
include('db.php');
include('acc_function.php');
if(isset($_POST["operation"]))
{
	if($_POST["operation"] == "Add")
	{
		$image = '';
		if($_FILES["user_image"]["name"] != '')
		{
			$image = upload_image();
		}
		$statement = $connection->prepare("
			INSERT INTO tbl_account (uname, password, position, image) 
			VALUES (:uname, :password, :position, :image)
		");
		$result = $statement->execute(
			array(
				':uname'	=>	$_POST["uname"],
				':password'	=>	$_POST["password"],
				':position'	=>	$_POST["position"],
				':image'		=>	$image
			)
		);
		if(!empty($result))
		{
			echo 'Data Inserted';
		}
	}
	if($_POST["operation"] == "Edit")
	{
		$image = '';
		if($_FILES["user_image"]["name"] != '')
		{
			$image = upload_image();
		}
		else
		{
			$image = $_POST["hidden_user_image"];
		}
		$statement = $connection->prepare(
			"UPDATE tbl_account 
			SET uname = :uname, password = :password, position = :position, image = :image  
			WHERE id = :id
			"
		);
		$result = $statement->execute(
			array(
				':uname'	=>	$_POST["uname"],
				':password'	=>	$_POST["password"],
				':position'	=>	$_POST["position"],
				':image'		=>	$image,
				':id'			=>	$_POST["user_id"]
			)
		);
		if(!empty($result))
		{
			echo 'Data Updated';
		}
	}
}

?>